---
severity: Awareness
pillar: Operational Excellence
category: Deployment
resource: Data Factory
online version: https://azure.github.io/PSRule.Rules.Azure/en/rules/Azure.DataFactory.Version/
---

# Use Data Factory v2

## SYNOPSIS

Consider migrating to DataFactory v2.

## DESCRIPTION

Consider migrating to DataFactory v2.

## RECOMMENDATION

Consider migrating to DataFactory v2.
